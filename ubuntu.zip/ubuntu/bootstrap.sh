#!/usr/bin/env bash

mv /tmp/.tmux.conf /etc/skel
mv /tmp/.config /etc/skel

cp -r /etc/skel/.tmux.conf /home/vagrant
cp -r /etc/skel/.config /home/vagrant

add-apt-repository ppa:neovim-ppa/unstable
apt-get update

apt-get install -y aptitude build-essential git neovim libevent-dev libncurses-dev \
python-dev python-pip python3-dev python3-pip linux-headers-$(uname -r) golang-go \
cmake clang libclang-dev

mkdir /src && cd /src

wget https://github.com/tmux/tmux/releases/download/2.2/tmux-2.2.tar.gz
tar xvzf tmux-2.2.tar.gz
cd tmux-2.2/
./configure && make
make install

pip2 install --upgrade wheezy.template cython quickfix pyinstaller nose flask flask-wtf \
    sphinx sphinx_rtd_theme wtforms-json Twisted==15.0.0
pip2 install --egg SCons
pip3 install --upgrade neovim
